import React from 'react';
import ToDoItem from './ToDoItem';

const ToDoList = ({ todos, onDelete, onToggle, onEdit }) => {
    return (
        <div className="mt-4">
            {todos.length === 0 ? (
                <div className="alert alert-info text-center shadow-sm" style={{ fontFamily: 'Inter, sans-serif' }}>
                    <span className="fw-semibold">No todos yet!</span> Add one above.
                </div>
            ) : (
                todos.map((todo) => (
                    <ToDoItem
                        key={todo.id}
                        todo={todo}
                        onDelete={onDelete}
                        onToggle={onToggle}
                        onEdit={onEdit}
                    />
                ))
            )}
        </div>
    );
};

export default ToDoList; 