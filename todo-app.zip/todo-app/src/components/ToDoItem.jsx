import React, { useState } from 'react';

const ToDoItem = ({ todo, onDelete, onToggle, onEdit }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editText, setEditText] = useState(todo.text);

    const handleEdit = () => {
        if (isEditing) {
            onEdit(todo.id, editText);
        }
        setIsEditing(!isEditing);
    };

    return (
        <div
            className="card mb-3 border-0 shadow-sm todo-item"
            style={{
                background: 'linear-gradient(90deg, #fff 60%, #e0f2fe 100%)',
                borderLeft: '6px solid #0ea5e9',
            }}
        >
            <div className="card-body d-flex align-items-center justify-content-between py-3">
                <div className="d-flex align-items-center gap-3 flex-grow-1">
                    <input
                        type="checkbox"
                        checked={todo.completed}
                        onChange={() => onToggle(todo.id)}
                        className="form-check-input me-2"
                        style={{ width: 22, height: 22 }}
                    />
                    {isEditing ? (
                        <input
                            type="text"
                            value={editText}
                            onChange={(e) => setEditText(e.target.value)}
                            className="form-control"
                            autoFocus
                        />
                    ) : (
                        <span
                            className={`fs-5 ${todo.completed ? 'text-decoration-line-through text-secondary' : ''}`}
                            style={{ fontFamily: 'Inter, sans-serif' }}
                        >
                            {todo.text}
                        </span>
                    )}
                </div>
                <div className="d-flex gap-2 ms-3">
                    <button
                        onClick={handleEdit}
                        className="btn btn-sm text-white fw-semibold"
                        style={{
                            background: 'linear-gradient(90deg, #fbbf24 0%, #f59e42 100%)',
                        }}
                    >
                        {isEditing ? 'Save' : 'Edit'}
                    </button>
                    <button
                        onClick={() => onDelete(todo.id)}
                        className="btn btn-sm text-white fw-semibold"
                        style={{
                            background: 'linear-gradient(90deg, #ef4444 0%, #f87171 100%)',
                        }}
                    >
                        Delete
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ToDoItem; 