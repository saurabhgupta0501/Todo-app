import React from 'react';

const Header = () => {
    return (
        <header className="mb-4">
            <div
                className="card text-white shadow-lg border-0"
                style={{
                    background: 'linear-gradient(90deg, #0ea5e9 0%, #38bdf8 100%)',
                    fontFamily: 'Inter, sans-serif',
                }}
            >
                <div className="card-body py-4">
                    <h1 className="card-title text-center display-5 fw-bold mb-0">
                        Todo List App
                    </h1>
                </div>
            </div>
        </header>
    );
};

export default Header; 